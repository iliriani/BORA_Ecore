// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License. See License.txt in the project root for license information.

package example;

import com.microsoft.commondatamodel.objectmodel.cdm.CdmArgumentDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmAttributeItem;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmConstantEntityDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmCorpusDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmDataPartitionDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmE2ERelationship;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmEntityCollection;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmEntityDeclarationDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmEntityDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmEntityReference;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmManifestDeclarationDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmManifestDefinition;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmTraitReference;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmTraitReferenceBase;
import com.microsoft.commondatamodel.objectmodel.cdm.CdmTypeAttributeDefinition;
import com.microsoft.commondatamodel.objectmodel.enums.CdmStatusLevel;
import com.microsoft.commondatamodel.objectmodel.storage.LocalAdapter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;

import org.apache.commons.lang3.StringUtils;

/**
 * -------------------------------------------------------------------------------------------------
 * This sample reads the content of a manifest document and lists all the entities that it knows
 * about. For a given entity, the sample will get the corresponding schema definition document for
 * that entity and allow the user to list its attributes, traits, properties, data partition file
 * locations, and relationships.
 * -------------------------------------------------------------------------------------------------
 */
public class Program {
  private final static Scanner SCANNER = new Scanner(System.in);
  
	public  static String header="";
	public  static String clAttr="";
	public static String attFooter="</Attributes>\t\n </j.0:hasChild>\t\n";
	
	public static String conHeder = "  <j.0:hasChild>\r\n "
			+ " <Associations>\r\n";
	public  static String con="";
	public static String conFooter = "</Associations>";
	
	public  static String clHeader="";
	public  static String clFoot="";
	public  static String footer="";
	
	public  static String rdfFile="";
	public static String MName = "";
	

  public static void main(final String[] args) {

    // ---------------------------------------------------------------------------------------------
    // Instantiate a corpus. The corpus is the collection of all documents and folders created
    // or discovered while navigating objects and paths.

    final CdmCorpusDefinition cdmCorpus = new CdmCorpusDefinition();

     // set callback to receive error and warning logs.
    cdmCorpus.setEventCallback((level, message) -> {
      System.out.println(message);
    }, CdmStatusLevel.Warning);

    // ---------------------------------------------------------------------------------------------
    // Configure storage adapters and mount them to the corpus.

    // We want our storage adapters to point at the local manifest location
    // and at the example public standards.
    final String pathFromExeToExampleRoot = "../../";

    cdmCorpus.getStorage().mount(
        "local",
//        new LocalAdapter(pathFromExeToExampleRoot + "1-read-manifest/sample-data"));
        new LocalAdapter(pathFromExeToExampleRoot + "../schemaDocuments/core/operationsCommon/Entities/System/Workflow/"));

    // 'local' is our default namespace.
    // Any paths that start navigating without a device tag (ex. 'cdm')
    // will just default to the 'local' namespace.
    cdmCorpus.getStorage().setDefaultNamespace("local");

    // Storage adapter pointing to the example public standards.
    // This is a fake 'cdm'; normally the CDM Standards adapter would be
    // used to point at the real public standards.
    // Mount it as the 'cdm' device, not the default,
    // so that we must use "cdm:<folder-path>" to get there.
    cdmCorpus.getStorage().mount(
        "cdm",
//        new LocalAdapter(pathFromExeToExampleRoot + "example-public-standards"));
        new LocalAdapter(pathFromExeToExampleRoot + "../schemaDocuments"));

    // Example how to mount to the ADLS.
    // final AdlsAdapter adlsAdapter = new AdlsAdapter(
    //     "<ACCOUNT_NAME>.dfs.core.windows.net", // Hostname.
    //     "/<FILESYSTEM-NAME>", // Root.
    //     "72f988bf-86f1-41af-91ab-2d7cd011db47", // Tenant ID.
    //     "<CLIENT_ID>", // Client ID.
    //     "<CLIENT_SECRET>" // Client secret.
    // );
    // cdmCorpus.getStorage().mount("adls", adlsAdapter);

    // ---------------------------------------------------------------------------------------------
    // Open the default manifest file at the root.
    
    exploreManifest(cdmCorpus, "Workflow.manifest.cdm.json");
  }

  static void exploreManifest(CdmCorpusDefinition cdmCorpus, String manifestPath) {
    // ---------------------------------------------------------------------------------------------
    // List all the entities found in the manifest
    // and allow the user to choose which entity to explore.

    System.out.println("\nLoading manifest " + manifestPath + " ...");
    
    CdmManifestDefinition manifest = cdmCorpus.<CdmManifestDefinition>fetchObjectAsync(manifestPath).join();

    if (manifest == null) {
      System.err.println("Unable to load manifest " + manifestPath + ". Please inspect error log for additional details.");
      return;
    }

    while (true) {
      int index = 1;

      if (manifest.getEntities().size() > 0) {
        System.out.println("List of all entities:");

        for (final CdmEntityDeclarationDefinition entityDeclaration : manifest.getEntities()) {
          // Print entity declarations.
          // Assume there are only local entities in this manifest for simplicity.
          System.out.print("  " + StringUtils.rightPad(Integer.toString(index), 3));
          System.out.print("  " + StringUtils.rightPad(entityDeclaration.getEntityName(), 35));
          System.out.println(entityDeclaration.getEntityPath());
          
          
          index++;
        }
      }

      if (manifest.getSubManifests().size() > 0) {
        System.out.println("List of all sub-manifests:");

        for (final CdmManifestDeclarationDefinition manifestDeclaration : manifest.getSubManifests()) {
          // Print sub-manifest declarations.
          System.out.print("  " + StringUtils.rightPad(Integer.toString(index), 3));
          System.out.print("  " + StringUtils.rightPad(manifestDeclaration.getManifestName(), 35));
          System.out.println(manifestDeclaration.getDefinition());
          index++;
        }
      }
      
      if (index == 1) {
        System.out.println("No Entities or Sub-manifest found. Press [enter] to exit.");
        SCANNER.nextLine();
        break;
      }

      System.out.println("Enter a number to show details for that Entity or Sub-manifest (press [enter] to exit): ");
      // Get the user's choice.
      String input = SCANNER.nextLine();
      if (com.microsoft.commondatamodel.objectmodel.utilities.StringUtils.isNullOrEmpty(input)) {
        break;
      }

      // Make sure the user's input is a number.
      final int num;

      try {
        num = Integer.parseInt(input);
      } catch (final NumberFormatException ne) {
        System.out.println("\nEnter a number.");
        System.out.println();
        continue;
      }

      if (num > manifest.getEntities().size()) {
        int subNum = num - manifest.getEntities().size() - 1;
        exploreManifest(cdmCorpus, cdmCorpus.getStorage().createAbsoluteCorpusPath(manifest.getSubManifests().get(subNum).getDefinition(), manifest));
        continue;
      }

      index = 1;
      for (final CdmEntityDeclarationDefinition entityDeclaration : manifest.getEntities()) {
        if (index == num) {
          System.out.println(
              "Reading the entity schema and resolving with the standard docs, "
                  + "first one may take a second ...");

          // From the path to the entity, get the actual schema description.
          // Take the local relative path in this doc and make sure it works.
          final CdmEntityDefinition entSelected =
              cdmCorpus.<CdmEntityDefinition>fetchObjectAsync(
                  entityDeclaration.getEntityPath(),
                  manifest)
                  .join(); // Gets the entity object from the doc.

          while (true) {
            System.out.println("\nMetadata properties for the entity "
                    + entityDeclaration.getEntityName() + ":");
            System.out.println("  1: Attributes");
            System.out.println("  2: Traits");
            System.out.println("  3: Properties");
            System.out.println("  4: Data partition locations");
            System.out.println("  5: Relationships");

            System.out.println("Enter a number to show details for that metadata "
              + "property (press [enter] to explore other entities):");

            // Get the user's choice.
            input = SCANNER.nextLine();
            if (com.microsoft.commondatamodel.objectmodel.utilities.StringUtils.isNullOrEmpty(input)) {
              break;
            }

            // Make sure the user's input is a number.
            final int choice;
            try {
              choice = Integer.parseInt(input);
              switch (choice) {
                // List the entity's attributes.
                case 1:
                  listAttributes(entSelected);
                  break;
                // List the entity's traits.
                case 2:
                  listTraits(entSelected);
                  break;
                // List the entity's properties.
                case 3:
                  listProperties(entSelected, entityDeclaration);
                  break;
                // List the entity's data partition locations.
                case 4:
                  listDataPartitionLocations(cdmCorpus, entityDeclaration);
                  break;
                // List the entity's relationships.
                case 5:
                	
				String strFile;
				try {
					strFile = convertToRDF(cdmCorpus, manifest, entSelected);
					
					createFile(strFile,entSelected.getName(),manifest.getName());
                	
	                  if (manifest.getRelationships() != null
	                      && manifest.getRelationships().getCount() > 0) {
	                    // The manifest file contains pre-calculated entity relationships,
	                    // so we can read them directly.
	                    listRelationshipsFromManifest(manifest, entSelected);
	                  } else {
	                    // The manifest file doesn't contain relationships,
	                    // so we have to compute the relationships first.
	                    cdmCorpus.calculateEntityGraphAsync(manifest).join();
	                    listRelationships(cdmCorpus, entSelected);
	                  }
	                  break;
				} catch (Exception e) {
					e.printStackTrace();
				} 
                	
                default:
                  System.out.println("\nEnter a number between 1-5.");
                  break;
              }
            } catch (final NumberFormatException ne) {
              System.out.println("\nEnter a number.");
            }
          }
        }
        index++;
      }
    }
  }

  static void listAttributes(final CdmEntityDefinition entity) {
    System.out.println("\nList of all attributes for the entity " + entity.getEntityName() + ":");

    // This way of getting the attributes only works well for 'resolved' entities
    // that have been flattened out.
    // An abstract entity can be resolved by calling createResolvedEntity on it.
    try {
    CdmEntityDefinition resolvedEntity = entity.createResolvedEntityAsync("defualt").get();
    for (final CdmAttributeItem attribute : resolvedEntity.getAttributes()) {
//    	for (final CdmAttributeItem attribute : entity.getAttributes()) {	
      if (attribute instanceof CdmTypeAttributeDefinition) {
        final CdmTypeAttributeDefinition typeAttributeDefinition =
            (CdmTypeAttributeDefinition) attribute;
        // Attribute's name.
        printProperty("Name", typeAttributeDefinition.getName());
        // Attribute's data format.
        printProperty("DataFormat", typeAttributeDefinition.fetchDataFormat().name());
        // And all the traits of this attribute.
        System.out.println("AppliedTraits:");
        typeAttributeDefinition.getAppliedTraits().forEach(Program::printTrait);
        System.out.println();
      }
    }
    
  }catch (Exception e) {
	e.printStackTrace();
}
  }

  static void listTraits(final CdmEntityDefinition entity) {
    System.out.println("\nList of all traits for the entity " + entity.getEntityName() + ":");
    entity.getExhibitsTraits().forEach(Program::printTrait);
  }

  static void listProperties(final CdmEntityDefinition entity, final CdmEntityDeclarationDefinition entityDec) {
    System.out.println("\nList of all properties for the entity " + entity.getEntityName() + ":");
    // Entity's name.
    printProperty("EntityName", entityDec.getEntityName());
    // Entity that this entity extends from.
    if (entity.getExtendsEntity() != null) {
      printProperty(
          "ExtendsEntity",
          entity.getExtendsEntity().fetchObjectDefinitionName());
    }
    // Entity's display name.
    printProperty("DisplayName", entity.getDisplayName());
    // Entity's description.
    printProperty("Description", entity.getDescription());
    // Version.
    printProperty("Version", entity.getVersion());
    if (entity.getCdmSchemas() != null) {
      // Cdm schemas.
      System.out.println("  CdmSchemas:");
      entity.getCdmSchemas().forEach(schema -> System.out.println("      " + schema));
    }
    // Entity's source name.
    printProperty("SourceName", entity.getSourceName());
    // Last file modified time.
    if (entityDec.getLastFileModifiedTime() != null) {
      printProperty(
          "LastFileModifiedTime",
          entityDec.getLastFileModifiedTime().toString());
    }
    if (entityDec.getLastFileStatusCheckTime() != null) {
      // Last file status check time.
      printProperty(
          "LastFileStatusCheckTime",
          entityDec.getLastFileStatusCheckTime().toString());
    }
  }

  static void listDataPartitionLocations(final CdmCorpusDefinition cdmCorpus, final CdmEntityDeclarationDefinition entityDeclaration) {
    System.out.println("\nList of all data partition locations for the entity " +
        entityDeclaration.getEntityName() + ":");
    for (final CdmDataPartitionDefinition dataPartition : entityDeclaration.getDataPartitions()) {
      // The data partition location.
      System.out.println("  " + dataPartition.getLocation());

      if (!com.microsoft.commondatamodel.objectmodel.utilities.StringUtils.isNullOrEmpty(dataPartition.getLocation())) {
        System.out.println("  " + cdmCorpus.getStorage().corpusPathToAdapterPath(dataPartition.getLocation()));
      }
    }
  }

  static void listRelationships(
      final CdmCorpusDefinition cdmCorpus,
      final CdmEntityDefinition entity) {
    System.out.println(
        "\nList of all relationships for the entity " + entity.getEntityName() + ":"
    );
    
//	  System.out.println("Nga Lili ky test code eshte: --------------------");
//	  System.out.println("Ktu eshte ka hin");
//	  System.out.println(" Income From: "+cdmCorpus.fetchIncomingRelationships(entity).get(0).getFromEntity());
//	  System.out.println(" Income To: "+cdmCorpus.fetchIncomingRelationships(entity).get(0).getToEntity());
//	  System.out.println("---------------------");
//	  System.out.println("Outgoing from: "+cdmCorpus.fetchOutgoingRelationships(entity).get(0).getFromEntity());
//	  System.out.println("Outgoing from: "+cdmCorpus.fetchOutgoingRelationships(entity).get(0).getToEntity());
//	  System.out.println("-------------------------------------------------");
    
    // Loop through all the relationships where other entities point to this entity.
    cdmCorpus.fetchIncomingRelationships(entity).forEach(Program::printRelationship);
    // Now loop through all the relationships where this entity points to other entities.
    cdmCorpus.fetchOutgoingRelationships(entity).forEach(Program::printRelationship);
  }

  static void listRelationshipsFromManifest(
      final CdmManifestDefinition manifest,
      final CdmEntityDefinition entity) {
    System.out.println(
        "\nList of all relationships for the entity " + entity.getEntityName() + ":"
    );
    for (final CdmE2ERelationship relationship : manifest.getRelationships()) {
      // Currently, the easiest way to get a specific entity's relationships
      // (given a resolved manifest) is to just look at all the entity relationships
      // in the resolved manifest, and then filtering.
      if (relationship.getFromEntity().contains(entity.getEntityName())
          || relationship.getToEntity().contains(entity.getEntityName())) {
    	  
//    	  System.out.println("Nga Lili ky test code eshte: --------------------");
//    	  System.out.println(relationship.getFromEntity()+" dhe "+ relationship.getToEntity());
//    	  System.out.println("---------------------");
        printRelationship(relationship);
      }
    }
  }

  static void printTrait(CdmTraitReferenceBase trait) {
    if (!com.microsoft.commondatamodel.objectmodel.utilities.StringUtils.isNullOrEmpty(trait.fetchObjectDefinitionName())) {
      System.out.println("      " + trait.fetchObjectDefinitionName());

      if (trait instanceof CdmTraitReference) {
        for (CdmArgumentDefinition argDef : ((CdmTraitReference) trait).getArguments()) {
          if (argDef.getValue() instanceof CdmEntityReference) {
            System.out.println("         Constant: [");

            CdmConstantEntityDefinition contEntDef = 
              ((CdmEntityReference)argDef.getValue()).fetchObjectDefinition();

            for (List<String> constantValueList : contEntDef.getConstantValues()) {
                System.out.println("             " + constantValueList);
            }
            System.out.println("         ]");
          }
          else
          {
            // Default output, nothing fancy for now
            System.out.println("         " + argDef.getValue());
          }
        }
      }
    }
  }

  static void printProperty(final String propertyName, final String propertyValue) {
    if (!com.microsoft.commondatamodel.objectmodel.utilities.StringUtils.isNullOrEmpty(propertyValue)) {
      System.out.println("  " + propertyName + ":" + " " + propertyValue);
    }
  }

  static void printRelationship(final CdmE2ERelationship relationship) {
    System.out.println("  FromEntity: " + relationship.getFromEntity())  ;
    System.out.println("  FromEntityAttribute: " + relationship.getFromEntityAttribute());
    System.out.println("  ToEntity: " + relationship.getToEntity());
    System.out.println("  ToEntityAttribute: " + relationship.getToEntityAttribute());
    System.out.println();
  }
  
  
  
  public static String convertToRDF(CdmCorpusDefinition cdmCorpus, CdmManifestDefinition manifest, CdmEntityDefinition entity) throws InterruptedException, ExecutionException {
	  
	  EncoderToRDF encode = new EncoderToRDF();
	  
	  MName = manifest.getName(); 
	  
	  header = encode.getHeader(manifest.getName());
	  clHeader = encode.getClassHeader();
	  clFoot = encode.getClassBody(manifest.getName(),entity.getName());
	  	
	    CdmEntityDefinition resolvedEntity = entity.createResolvedEntityAsync("defualt").get();
	    for (final CdmAttributeItem attribute : resolvedEntity.getAttributes()) {
//	  	for (final CdmAttributeItem attribute : entity.getAttributes()) {
	        if (attribute instanceof CdmTypeAttributeDefinition) {
	          final CdmTypeAttributeDefinition typeAttributeDefinition =
	              (CdmTypeAttributeDefinition) attribute;
	          
	          String dt = swtichDataDtypes(typeAttributeDefinition.fetchDataFormat().name());
	          
	          clAttr = clAttr + encode.getAttributes(typeAttributeDefinition.getName(), dt) + "\r\n";
	          
	        }
	      }
	    
        if (manifest.getRelationships() != null
                && manifest.getRelationships().getCount() > 0) {

    	    for (final CdmE2ERelationship relationship : manifest.getRelationships()) {
    	        if (relationship.getFromEntity().contains(entity.getEntityName())
    	            || relationship.getToEntity().contains(entity.getEntityName())) {
    	        	
    	        	con = con + encode.getAssociation(MName, cutClassName(relationship.getFromEntity()) , cutClassName(relationship.getToEntity())) + "\r\n";
    	        }
    	      }
    	    
            } else {

              cdmCorpus.calculateEntityGraphAsync(manifest).join();
              for(CdmE2ERelationship inRelation: cdmCorpus.fetchIncomingRelationships(entity)) {
            	  con = con + encode.getAssociation(MName, cutClassName(inRelation.getFromEntity()) , cutClassName(inRelation.getToEntity())) + "\r\n";
              }
              
//              if(cdmCorpus.fetchOutgoingRelationships(entity).get(0) != null) {
//            	  for(CdmE2ERelationship outRelation: cdmCorpus.fetchOutgoingRelationships(entity)) {
//                	  con = con + encode.getAssociation(MName, cutClassName(outRelation.getFromEntity()) , cutClassName(outRelation.getToEntity())) + "\r\n";
//                  }
//              }

            }
        
		footer = encode.getFooter();

		rdfFile = header+ "\t\n" + clHeader+ "\t\n"+ clAttr+ "\t\n" +attFooter+"\t\n" +clFoot+ "\t\n" +conHeder + "\t\n" +con+ "\t\n"+ conFooter + "\t\n"+ footer;
		
		String file = rdfFile;
				
		header="";clHeader="";clAttr="";clFoot="";con="";footer = "";
	    
	    return file;	    
	  
  }
  
  
  public static void convertAllEntities(CdmCorpusDefinition cdmCorpus, CdmManifestDefinition manifest) {
	  
	  CdmEntityCollection allEntities = manifest.getEntities();
	  
	  for(CdmEntityDeclarationDefinition entity: allEntities) {
//		  String textRDF = convertToRDF(cdmCorpus, manifest, entity.getObjectType());
	  }
  }
  
  
  public static void createFile(String text, String name, String manif) {
	  
  	FileOutputStream out;
	try {
//		out = new FileOutputStream("C:\\Users\\Admin\\Desktop\\Models\\CDM\\"+name+".rdf");
//	  	byte[] strToBytes = text.getBytes();
//	      out.write(strToBytes);
//	      out.close();      
	      File f = new File("C:\\Users\\Admin\\Desktop\\Models\\CDM\\"+name+"-"+manif+".rdf");
	      if(!f.exists()){
	          f.createNewFile();
	      }
	      
	      
	      FileWriter fileWriter = new FileWriter(f, false);

	      BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
	      bufferedWriter.write(text);
	      bufferedWriter.close();

	      System.out.println("Done");
	      
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

  }
  
  
  
  public static String cutClassName(String comPath) {
	  
	  int lastBaskLashPosition = 0;
      for (int i = comPath.length() - 1; i >= 0; i--) {
          if(comPath.charAt(i) == '/') {
        	  lastBaskLashPosition = comPath.length() - i;
        	  break;
          }
       }
      
      int startPoint = comPath.length()-lastBaskLashPosition +1;
      
	  String cl = comPath.substring(startPoint, comPath.length());
      
	  return cl;
  }
  
  
  public static String swtichDataDtypes(String dt) {
	  
String dataTY = "";
	  
switch (dt.toLowerCase()) {
	case "any": 
		dataTY = "String"; break; 
	case "addressline":
		dataTY = "String"; break;
	case "age":
		dataTY = "Int"; break;
	case "ampere":
		dataTY = "double"; break;
	case "attribute":
		dataTY = "String"; break;
	case "attributegroup":
		dataTY = "String"; break;
	case "attributename":
		dataTY = "String"; break;
	case "basecurrency":
		dataTY = "decimal"; break;
	case "biginteger":
		dataTY = "int"; break;
	case "binary":
		dataTY = "byte"; break;
	case "birthdate":
		dataTY = "DateTime"; break;
	case "boolean":
		dataTY = "bool"; break;
	case "byte":
		dataTY = "byte"; break;
	case "candela":
		dataTY = "double"; break;
	case "cdmobject":
		dataTY = "String"; break;
	case "celsius":
		dataTY = "double"; break;
	case "centimeter":
		dataTY = "double"; break;
	case "char":
		dataTY = "char"; break;
	case "city":
		dataTY = "String"; break;
	case "colorname":
		dataTY = "String"; break;
	case "companyname":
		dataTY = "String"; break;
	case "coulomb":
		dataTY = "double"; break;
	case "country":
		dataTY = "String"; break;
	case "county":
		dataTY = "String"; break;
	case "culutretag":
		dataTY = "String"; break;
	case "currency":
		dataTY = "decimal"; break;
	case "currencycode":
		dataTY = "String"; break;
	case "datatype":
		dataTY = "String"; break;
	case "date":
		dataTY = "DateTime"; break;
	case "dataTimeoffset":
		dataTY = "DateTime"; break;
	case "day":
		dataTY = "int"; break;
	case "decimal":
		dataTY = "decimal"; break;
	case "degree":
		dataTY = "double"; break;
	case "displayorder":
		dataTY = "int"; break;
	case "double":
		dataTY = "double"; break;
	case "email":
		dataTY = "String"; break;
	case "entity":
		dataTY = "String"; break;
	case "entityid":
		dataTY = "String"; break;
	case "entityname":
		dataTY = "String"; break;
	case "farad":
		dataTY = "double"; break;
	case "fileid":
		dataTY = "String"; break;
	case "filename":
		dataTY = "String"; break;
	case "firstname":
		dataTY = "String"; break;
	case "fixeddecimal":
		dataTY = "decimal"; break;
	case "float":
		dataTY = "float"; break;
	case "fullname":
		dataTY = "String"; break;
	case "gender":
		dataTY = "String"; break;
	case "gigahertz":
		dataTY = "double"; break;
	case "gigapascal":
		dataTY = "double"; break;
	case "governmendtId":
		dataTY = "String"; break;
	case "gram":
		dataTY = "double"; break;
	case "guid":
		dataTY = "String"; break;
	case "hertz":
		dataTY = "double"; break;
	case "hour":
		dataTY = "int"; break;
	case "image":
		dataTY = "byte"; break;
	case "inches":
		dataTY = "double"; break;
	case "integer":
		dataTY = "int"; break;
	case "integercalendarpart":
		dataTY = "int"; break;
	case "ip4address":
		dataTY = "String"; break;
	case "ip6address":
		dataTY = "String"; break;
	case "joule":
		dataTY = "double"; break;
	case "jsinteger":
		dataTY = "decimal"; break;
	case "json":
		dataTY = "String"; break;
	case "kelvin":
		dataTY = "double"; break;
	case "kilogram":
		dataTY = "double"; break;
	case "kilohertz":
		dataTY = "double"; break;
	case "kilometer":
		dataTY = "double"; break;
	case "kiloohm":
		dataTY = "double"; break;
	case "kilopascal":
		dataTY = "double"; break;
	case "kilovolt":
		dataTY = "double"; break;
	case "kilowatt":
		dataTY = "double"; break;
	case "language":
		dataTY = "String"; break;
	case "languageTag":
		dataTY = "String"; break;
	case "lastname":
		dataTY = "String"; break;
	case "latitude":
		dataTY = "double"; break;
	case "list":
		dataTY = "String"; break;
	case "listlookup":
		dataTY = "int"; break;
	case "listlookupcorrelated":
		dataTY = "int"; break;
	case "listlookupmultiple":
		dataTY = "String"; break;
	case "listlookupstring":
		dataTY = "String"; break;
	case "listlookupwellknown":
		dataTY = "String"; break;
	case "localizeddisplaytext":
		dataTY = "String"; break;
	case "localizeddisplaytextmultiple":
		dataTY = "String"; break;
	case "longitude":
		dataTY = "double"; break;
	case "maritalStatus":
		dataTY = "String"; break;
	case "megahertz":
		dataTY = "double"; break;
	case "megaOhm":
		dataTY = "double"; break;
	case "megapascal":
		dataTY = "double"; break;
	case "megavolt":
		dataTY = "double"; break;
	case "megawatt":
		dataTY = "double"; break;
	case "meter":
		dataTY = "double"; break;
	case "microampere":
		dataTY = "double"; break;
	case "microfarad":
		dataTY = "double"; break;
	case "microsecond":
		dataTY = "double"; break;
	case "middlename":
		dataTY = "String"; break;
	case "milliampere":
		dataTY = "double"; break;
	case "miligram":
		dataTY = "double"; break;
	case "millimeter":
		dataTY = "double"; break;
	case "millisecond":
		dataTY = "double"; break;
	case "millivolt":
		dataTY = "double"; break;
	case "milliwatt":
		dataTY = "double"; break;
	case "minute":
		dataTY = "int"; break;
	case "minutes":
		dataTY = "int"; break;
	case "mole":
		dataTY = "double"; break;
	case "month":
		dataTY = "int"; break;
	case "name":
		dataTY = "String"; break;
	case "nanofarad":
		dataTY = "double"; break;
	case "newtonn":
		dataTY = "double"; break;
	case "object":
		dataTY = "String"; break;
	case "ohm":
		dataTY = "double"; break;
	case "pascal":
		dataTY = "double"; break;
	case "phone":
		dataTY = "String"; break;
	case "phonecell":
		dataTY = "String"; break;
	case "phonefax":
		dataTY = "String"; break;
	case "picofarad":
		dataTY = "double"; break;
	case "postalcode":
		dataTY = "String"; break;
	case "purpose":
		dataTY = "String"; break;
	case "quarter":
		dataTY = "int"; break;
	case "radian":
		dataTY = "double"; break;
	case "schar":
		dataTY = "String"; break;
	case "second":
		dataTY = "double"; break;
	case "smallInteger":
		dataTY = "int"; break;
	case "stateorprovince":
		dataTY = "String"; break;
	case "string":
		dataTY = "String"; break;
	case "stringFormat":
		dataTY = "String"; break;
	case "tenday":
		dataTY = "int"; break;
	case "tickersymbol":
		dataTY = "String"; break;
	case "time":
		dataTY = "DateTime"; break;
	case "timezone":
		dataTY = "String"; break;
	case "trait":
		dataTY = "String"; break;
	case "trimester":
		dataTY = "int"; break;
	case "uri":
		dataTY = "String"; break;
	case "url":
		dataTY = "String"; break;
	case "userid":
		dataTY = "String"; break;
	case "variabledecimal":
		dataTY = "decimal"; break;
	case "volt":
		dataTY = "double"; break;
	case "watt":
		dataTY = "double"; break;
	case "week":
		dataTY = "int"; break;
	case "xml":
		dataTY = "String"; break;
	case "year":
		dataTY = "int"; break;
		
	default:
		dataTY = "String"; break;
	}

	  
	  return dataTY;

  }
  
  
}
